/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import entities.Lekar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author i7
 */
public class LekarCrud {
        public static Lekar readLekarBySpecijalnost(String specijalnost) throws SQLException {
        Lekar l = new Lekar();
        try {
            DBUtil.openConnection();

            PreparedStatement stmt = DBUtil.con.prepareStatement("SELECT * FROM Lekar WHERE specijalnost=?");
            stmt.setString(1, specijalnost);
            ResultSet set = stmt.executeQuery();
            while (set.next()) {
                l.setLekar_id(set.getInt("lekar_id"));
                l.setIme(set.getString("ime"));
                l.setPrezime(set.getString("prezime"));
                l.setSpecijalnost(set.getString("specijalnost"));
                l.setRecept(set.getString("recept"));


            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        DBUtil.closeConnection();
        return l;
    }
}
