package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author i7
 */
public class DBUtil {

    public static Connection con = null;
    private static String url = "jdbc:mysql://localhost/";
    private static String dbName = "se201-projekatandrej";
    private static String username = "root";
    private static String password = "";

    public static void openConnection() throws SQLException {
        con = DriverManager.getConnection(url + dbName, username, password);
    }

    public static void closeConnection() throws SQLException {
        con.close();
    }
}
