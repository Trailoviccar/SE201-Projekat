package db;

import entities.Pacijent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class PacijentCrud {
     public static Pacijent insertPacijent(Pacijent pacijent) {

        try {
            DBUtil.openConnection();
            PreparedStatement stmt = DBUtil.con.prepareStatement("INSERT INTO pacijent(ime, prezime, brojKnjizice) VALUES (?, ?, ?);", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, pacijent.getIme());
            stmt.setString(2, pacijent.getPrezime());
            stmt.setString(3, pacijent.getBrojKnjizice());


            stmt.execute();

            ResultSet keys = stmt.getGeneratedKeys();

            while (keys.next()) {
                pacijent.setPacijent_id(keys.getInt(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(PacijentCrud.class.getName()).log(Level.SEVERE, null, ex);
        }
        return pacijent;
    }
}
