/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import entities.Pacijent;
import entities.Pregled;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author i7
 */
public class PregledCrud {
     public static Pregled insertPregled(Pregled pregled) {

        try {
            DBUtil.openConnection();
            PreparedStatement stmt = DBUtil.con.prepareStatement("INSERT INTO pregled(lekar_id, pacijent_id, izvestaj) VALUES (?, ?, ?);", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, pregled.getLekar_id());
            stmt.setInt(2, pregled.getPacijent_id());
            stmt.setString(3, pregled.getIzvestaj());


            stmt.execute();

            ResultSet keys = stmt.getGeneratedKeys();

            while (keys.next()) {
                pregled.setPregled_id(keys.getInt(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(PregledCrud.class.getName()).log(Level.SEVERE, null, ex);
        }
        return pregled;
    }
}
