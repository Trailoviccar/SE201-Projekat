/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;


/**
 *
 * @author i7
 */
public class Lekar {
    private int lekar_id;
    private String ime;
    private String prezime;
    private String specijalnost;
    private String recept;

    public Lekar() {
    }

    public Lekar(int lekar_id, String ime, String prezime, String specijalnost, String recept) {
        this.lekar_id = lekar_id;
        this.ime = ime;
        this.prezime = prezime;
        this.specijalnost = specijalnost;
        this.recept = recept;
    }

    public int getLekar_id() {
        return lekar_id;
    }

    public void setLekar_id(int lekar_id) {
        this.lekar_id = lekar_id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getSpecijalnost() {
        return specijalnost;
    }

    public void setSpecijalnost(String specijalnost) {
        this.specijalnost = specijalnost;
    }

    public String getRecept() {
        return recept;
    }

    public void setRecept(String recept) {
        this.recept = recept;
    }

    @Override
    public String toString() {
        return "Lekar{" + "lekar_id=" + lekar_id + ", ime=" + ime + ", prezime=" + prezime + ", specijalnost=" + specijalnost + ", recept=" + recept + '}';
    }

    
    
}
