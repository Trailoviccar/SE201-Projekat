/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author i7
 */
public class Pregled {
    private int pregled_id;
    private int lekar_id;
    private int pacijent_id;
    private String izvestaj;

    public Pregled() {
    }

    public Pregled(int pregled_id, int lekar_id, int pacijent_id, String izvestaj) {
        this.pregled_id = pregled_id;
        this.lekar_id = lekar_id;
        this.pacijent_id = pacijent_id;
        this.izvestaj = izvestaj;
    }

    public Pregled(int lekar_id, int pacijent_id, String izvestaj) {
        this.lekar_id = lekar_id;
        this.pacijent_id = pacijent_id;
        this.izvestaj = izvestaj;
    }

    public int getPregled_id() {
        return pregled_id;
    }

    public void setPregled_id(int pregled_id) {
        this.pregled_id = pregled_id;
    }

    public int getLekar_id() {
        return lekar_id;
    }

    public void setLekar_id(int lekar_id) {
        this.lekar_id = lekar_id;
    }

    public int getPacijent_id() {
        return pacijent_id;
    }

    public void setPacijent_id(int pacijent_id) {
        this.pacijent_id = pacijent_id;
    }

    public String getIzvestaj() {
        return izvestaj;
    }

    public void setIzvestaj(String izvestaj) {
        this.izvestaj = izvestaj;
    }

    @Override
    public String toString() {
        return "Pregled{" + "pregled_id=" + pregled_id + ", lekar_id=" + lekar_id + ", pacijent_id=" + pacijent_id + ", izvestaj=" + izvestaj + '}';
    }
    
}
