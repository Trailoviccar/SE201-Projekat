/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author i7
 */
public class Pacijent {
    private int pacijent_id;
    private String ime;
    private String prezime;
    private String brojKnjizice;

    public Pacijent() {
    }

    public Pacijent(int pacijent_id, String ime, String prezime, String brojKnjizice) {
        this.pacijent_id = pacijent_id;
        this.ime = ime;
        this.prezime = prezime;
        this.brojKnjizice = brojKnjizice;
    }

    public Pacijent(String ime, String prezime, String brojKnjizice) {
        this.ime = ime;
        this.prezime = prezime;
        this.brojKnjizice = brojKnjizice;
    }
    
    

    public int getPacijent_id() {
        return pacijent_id;
    }

    public void setPacijent_id(int pacijent_id) {
        this.pacijent_id = pacijent_id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getBrojKnjizice() {
        return brojKnjizice;
    }

    public void setBrojKnjizice(String brojKnjizice) {
        this.brojKnjizice = brojKnjizice;
    }

    @Override
    public String toString() {
        return "Pacijent{" + "pacijent_id=" + pacijent_id + ", ime=" + ime + ", prezime=" + prezime + ", brojKnjizice=" + brojKnjizice + '}';
    }

   
    
}
