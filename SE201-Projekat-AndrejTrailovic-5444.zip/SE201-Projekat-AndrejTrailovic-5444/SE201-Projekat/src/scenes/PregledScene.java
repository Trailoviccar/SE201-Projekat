/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package scenes;

import entities.Lekar;
import entities.Pacijent;
import entities.Pregled;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author i7
 */
public class PregledScene extends Application {

    private Pacijent p;
    private Lekar l;
    private Pregled pregled;

    public PregledScene(Pacijent p, Lekar l, Pregled pregled) {
        this.p = p;
        this.l = l;
        this.pregled = pregled;
    }

    @Override
    public void start(Stage primaryStage) {
        Label  txt1 = new Label("Postovani " + p.getIme() + "\n\nVas izabrani lekar je: Dr. " + l.getIme() + " " + l.getPrezime() + ", " + l.getSpecijalnost() + "\n\nIzvestaj: " + pregled.getIzvestaj() + "\n\nRecept: " + l.getRecept());
        
        

        VBox root = new VBox(10);
        VBox v1 = new VBox(2);
        VBox v2 = new VBox(2);

//        v1.getChildren().addAll(text2, comboBox);
//        v2.getChildren().addAll(lbl, txt);

        root.getChildren().addAll(txt1);

        root.setPadding(new Insets(30));
        Scene scene = new Scene(root, 500, 350);

        primaryStage.setTitle("Pregled");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }

}
