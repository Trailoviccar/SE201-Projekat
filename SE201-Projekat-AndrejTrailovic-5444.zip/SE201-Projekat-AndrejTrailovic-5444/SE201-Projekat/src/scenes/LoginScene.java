
package scenes;

import entities.Pacijent;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class LoginScene extends Application {

    @Override
    public void start(Stage primaryStage) {
        Label imeLbl = new Label("Ime:");
        TextField imeTxt = new TextField();

        Label prezimeLbl = new Label("Prezime:");
        TextField prezimeTxt = new TextField();

        Label brojKnjiziceLbl = new Label("Broj Knjizice:");
        TextField brojKnjiziceTxt = new TextField();

        Button btnLogIn = new Button("Log in");

        btnLogIn.setOnAction((event) -> {
            if (imeTxt.getText().trim().equals("") || prezimeTxt.getText().trim().equals("") || brojKnjiziceTxt.getText().trim().equals("")) {
                prikaziAlert("Alert", "Sva polja su obavezna!");
            } else {

                Pacijent p = new Pacijent(imeTxt.getText().trim(), prezimeTxt.getText().trim(), brojKnjiziceTxt.getText().trim());
                db.PacijentCrud.insertPacijent(p);
                    primaryStage.close();
                    new OpcijeScene(p).start(primaryStage);

            }

        });

        VBox root = new VBox(10);
        VBox v1 = new VBox(2);
        VBox v2 = new VBox(2);
        VBox v3 = new VBox(2);
        v1.getChildren().addAll(imeLbl, imeTxt);
        v2.getChildren().addAll(prezimeLbl, prezimeTxt);
        v3.getChildren().addAll(brojKnjiziceLbl, brojKnjiziceTxt);
        root.getChildren().addAll( v1, v2, v3, btnLogIn);

        root.setPadding(new Insets(30));
        Scene scene = new Scene(root, 500, 350);

        primaryStage.setTitle("Log in");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void prikaziAlert(String naslov, String tekst) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(naslov);
        alert.setHeaderText(null);
        alert.setContentText(tekst);
        alert.showAndWait();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
