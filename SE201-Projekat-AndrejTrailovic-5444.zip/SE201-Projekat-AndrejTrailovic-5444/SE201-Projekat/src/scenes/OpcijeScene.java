/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package scenes;

import entities.Lekar;
import entities.Pacijent;
import entities.Pregled;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author i7
 */
public class OpcijeScene extends Application {

    private Pacijent p;

    public OpcijeScene(Pacijent p) {
        this.p = p;
    }

    @Override
    public void start(Stage primaryStage) {
        ComboBox<String> comboBox = new ComboBox<>();
        //Pacijent p = new Pacijent("vex", "sim", "123");
        Label text = new Label("Postovani " + p.getIme() + ",\nHvala na poverenju.");

        Label text2 = new Label("Izaberite vasu vrstu problema");
        comboBox.getItems().addAll("Prehlada", "Problemi sa srcem", "Problemi sa disanjem");

        Label lbl = new Label("Opisite vase tegobe:");
        TextField txt = new TextField();

        Button btnUnesi = new Button("Unesi");

        btnUnesi.setOnAction((event) -> {
            if (comboBox.getValue().trim().equals("") || txt.getText().trim().equals("")) {
                prikaziAlert("Alert", "Sva polja su obavezna!");
            } else {
                Lekar l = null;
                if(comboBox.getValue().equals("Problemi sa srcem")){
                    
                    try {
                        l = db.LekarCrud.readLekarBySpecijalnost("kardiolog");
                    } catch (SQLException ex) {
                        Logger.getLogger(OpcijeScene.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else if(comboBox.getValue().equals("Prehlada")){
                    
                    try {
                        l = db.LekarCrud.readLekarBySpecijalnost("lekar opste prakse");
                    } catch (SQLException ex) {
                        Logger.getLogger(OpcijeScene.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }else if(comboBox.getValue().equals("Problemi sa disanjem")){
                    
                    try {
                        l = db.LekarCrud.readLekarBySpecijalnost("pulmolog");
                    } catch (SQLException ex) {
                        Logger.getLogger(OpcijeScene.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                Pregled pregled = new Pregled( l.getLekar_id(), p.getPacijent_id(), txt.getText().trim());
                db.PregledCrud.insertPregled(pregled);
                primaryStage.close();
                new PregledScene(p,l, pregled).start(primaryStage);

            }

        });

        VBox root = new VBox(10);
        VBox v1 = new VBox(2);
        VBox v2 = new VBox(2);

        v1.getChildren().addAll(text2, comboBox);
        v2.getChildren().addAll(lbl, txt);

        root.getChildren().addAll(text, v1, v2,  btnUnesi);

        root.setPadding(new Insets(30));
        Scene scene = new Scene(root, 500, 350);

        primaryStage.setTitle("Opcije");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void prikaziAlert(String naslov, String tekst) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(naslov);
        alert.setHeaderText(null);
        alert.setContentText(tekst);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }

}
